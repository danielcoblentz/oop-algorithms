interface IntIterator {
    int next();
    boolean hasNext();
}

